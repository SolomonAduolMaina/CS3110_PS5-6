open Async.Std

let init addrs =
  failwith "Where you headed, cowboy?"

module Make (Job : MapReduce.Job) = struct
  let map_reduce inputs =
    failwith "Nowhere special."

end

