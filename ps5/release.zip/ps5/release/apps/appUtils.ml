
let whitespace =
  Str.regexp "[ \n\t,;.-!?()]+"

let split_words = Str.split whitespace

